This project depends on the Java wrapper for OpenCV.
The main idea of this is the ability to control your computer's mouse using your eyes.
The included test level images are only there to test one use of this project.